#!/usr/bin/env node
// Tiny static file server for local use (ES modules do not load from file:// in browsers).
// Binds to 127.0.0.1 only; serves index.html, style.css and src/ only. Adds the same strict CSP as the page.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const port = Number(process.env.PORT || 8080);
const types = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8' };

const server = http.createServer((req, res) => {
  let p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  if (p === '/') p = '/index.html';
  const ok = p === '/index.html' || p === '/style.css' || /^\/src\/[\w./-]+\.js$/.test(p);
  const file = path.join(root, p);
  if (!ok || p.includes('..') || !fs.existsSync(file)) { res.writeHead(404); res.end('not found'); return; }
  res.writeHead(200, { 'content-type': types[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer' });
  fs.createReadStream(file).pipe(res);
});
server.listen(port, '127.0.0.1', () => console.log(`Datemend (local) on http://127.0.0.1:${port}/`));
