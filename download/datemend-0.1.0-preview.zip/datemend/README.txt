Datemend v0.1.0 (preview): offline copy
=======================================
Datemend puts capture dates, locations and photo captions back on the files in a Snapchat "My Data" Memories export.
It runs entirely in your browser; this copy makes no network connections (see the Content-Security-Policy in index.html).

IMPORTANT: tested only on sample exports generated from third-party descriptions of the export format; NOT yet verified
against a real, current Snapchat export. Keep your original export. Not affiliated with Snap Inc.

Run it (browsers do not load ES modules from a double-clicked file, so serve the folder locally):
  node serve.mjs                 (Node 20+; then open http://127.0.0.1:8080/)
  or: python3 -m http.server 8080 --bind 127.0.0.1   (then open http://127.0.0.1:8080/)
Use desktop Chrome, Edge or Opera for "save to folder" and streaming zip save; other browsers get a zip download.

Source map:  src/pipeline.js (analyze -> plan -> run), src/export/* (zip discovery, manifest, matching),
             src/meta/* (JPEG/PNG EXIF, MP4 patch, time zones), src/zip/*, src/output/*, src/ui/app.js
Terms: see LICENSE-PREVIEW.txt (draft). Full documentation of limits: https://blackstonehealth.github.io/datemend/
